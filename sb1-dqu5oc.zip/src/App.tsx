import React, { useState } from 'react';
import { BarChart, Users, BookOpen, AlertCircle } from 'lucide-react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import StudentList from './components/StudentList';
import StudentDetails from './components/StudentDetails';

function App() {
  const [selectedView, setSelectedView] = useState('dashboard');
  const [selectedStudent, setSelectedStudent] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      <div className="flex flex-1">
        <Sidebar
          selectedView={selectedView}
          setSelectedView={setSelectedView}
          setSelectedStudent={setSelectedStudent}
        />
        <main className="flex-1 p-6">
          {selectedView === 'dashboard' && <Dashboard />}
          {selectedView === 'students' && !selectedStudent && (
            <StudentList setSelectedStudent={setSelectedStudent} />
          )}
          {selectedView === 'students' && selectedStudent && (
            <StudentDetails
              student={selectedStudent}
              setSelectedStudent={setSelectedStudent}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;