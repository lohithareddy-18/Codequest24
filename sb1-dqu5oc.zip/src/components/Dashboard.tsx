import React from 'react';
import { BarChart, Users, BookOpen, AlertCircle, TrendingDown } from 'lucide-react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Total Students', value: 5000, icon: Users },
    { label: 'At-Risk Students', value: 500, icon: AlertCircle },
    { label: 'Courses', value: 120, icon: BookOpen },
    { label: 'Avg. Performance', value: '78%', icon: BarChart },
    { label: 'Dropout Rate', value: '11%', icon: TrendingDown },
  ];

  const performanceData = {
    labels: ['Attendance', 'Assignments', 'Exams', 'Overall'],
    datasets: [
      {
        label: 'Average Performance',
        data: [85, 72, 68, 75],
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
      {
        label: 'At-Risk Students',
        data: [60, 55, 50, 55],
        backgroundColor: 'rgba(255, 99, 132, 0.6)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Student Performance Overview',
      },
    },
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-4 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
              <stat.icon size={32} className="text-blue-500" />
            </div>
          </div>
        ))}
      </div>
      <div className="bg-white p-6 rounded-lg shadow">
        <Bar options={options} data={performanceData} />
      </div>
    </div>
  );
};

export default Dashboard;