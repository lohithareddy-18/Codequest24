import React from 'react';
import { BarChart, Users, BookOpen, AlertCircle } from 'lucide-react';

interface SidebarProps {
  selectedView: string;
  setSelectedView: (view: string) => void;
  setSelectedStudent: (student: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ selectedView, setSelectedView, setSelectedStudent }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'alerts', label: 'Alerts', icon: AlertCircle },
  ];

  return (
    <aside className="bg-gray-800 text-white w-64 min-h-screen p-4">
      <nav>
        <ul>
          {menuItems.map((item) => (
            <li key={item.id} className="mb-2">
              <button
                className={`flex items-center space-x-2 w-full p-2 rounded ${
                  selectedView === item.id ? 'bg-blue-600' : 'hover:bg-gray-700'
                }`}
                onClick={() => {
                  setSelectedView(item.id);
                  setSelectedStudent(null);
                }}
              >
                <item.icon size={20} />
                <span>{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;