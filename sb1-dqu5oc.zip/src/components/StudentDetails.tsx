import React from 'react';
import { ArrowLeft, BookOpen, Clock, Award, AlertTriangle } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface Student {
  id: number;
  name: string;
  course: string;
  performance: number;
  atRisk: boolean;
}

interface StudentDetailsProps {
  student: Student;
  setSelectedStudent: (student: Student | null) => void;
}

const StudentDetails: React.FC<StudentDetailsProps> = ({ student, setSelectedStudent }) => {
  const performanceData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Performance',
        data: [65, 70, 62, 75, 68, student.performance],
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Student Performance Trend',
      },
    },
  };

  const factors = [
    { label: 'Attendance', value: '85%', icon: Clock },
    { label: 'Assignments', value: '72%', icon: BookOpen },
    { label: 'Exams', value: '68%', icon: Award },
  ];

  const solutions = [
    {
      category: 'Academic Support',
      items: [
        'Enroll in additional tutoring sessions for challenging subjects',
        'Participate in study groups to improve understanding of course material',
        'Utilize office hours to clarify concepts with professors',
      ],
    },
    {
      category: 'Time Management',
      items: [
        'Create a structured study schedule',
        'Use time management tools to prioritize tasks',
        'Set specific goals for each study session',
      ],
    },
    {
      category: 'Personal Well-being',
      items: [
        'Engage in regular physical exercise to reduce stress',
        'Practice mindfulness or meditation techniques',
        'Seek counseling services for emotional support if needed',
      ],
    },
  ];

  return (
    <div>
      <button
        className="flex items-center text-blue-600 mb-4"
        onClick={() => setSelectedStudent(null)}
      >
        <ArrowLeft size={20} className="mr-1" /> Back to Student List
      </button>
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{student.name}</h2>
          {student.atRisk && (
            <span className="bg-red-100 text-red-800 text-sm font-medium mr-2 px-2.5 py-0.5 rounded flex items-center">
              <AlertTriangle size={16} className="mr-1" /> At Risk
            </span>
          )}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Student Information</h3>
            <p><strong>Course:</strong> {student.course}</p>
            <p><strong>Overall Performance:</strong> {student.performance}%</p>
            <div className="mt-4">
              <h4 className="text-md font-semibold mb-2">Performance Factors</h4>
              <div className="grid grid-cols-3 gap-4">
                {factors.map((factor, index) => (
                  <div key={index} className="bg-gray-100 p-3 rounded-lg text-center">
                    <factor.icon size={24} className="mx-auto mb-2 text-blue-500" />
                    <p className="text-sm font-medium">{factor.label}</p>
                    <p className="text-lg font-bold">{factor.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Performance Trend</h3>
            <Line options={options} data={performanceData} />
          </div>
        </div>
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Recommended Solutions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {solutions.map((solution, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">{solution.category}</h4>
                <ul className="list-disc list-inside">
                  {solution.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="text-sm mb-1">{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDetails;