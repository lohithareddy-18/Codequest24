import React, { useState } from 'react';
import { Search, AlertCircle } from 'lucide-react';

interface Student {
  id: number;
  name: string;
  course: string;
  performance: number;
  atRisk: boolean;
}

const mockStudents: Student[] = [
  { id: 1, name: 'John Doe', course: 'Computer Science', performance: 75, atRisk: false },
  { id: 2, name: 'Jane Smith', course: 'Engineering', performance: 82, atRisk: false },
  { id: 3, name: 'Bob Johnson', course: 'Mathematics', performance: 58, atRisk: true },
  { id: 4, name: 'Alice Brown', course: 'Physics', performance: 90, atRisk: false },
  { id: 5, name: 'Charlie Davis', course: 'Chemistry', performance: 62, atRisk: true },
];

interface StudentListProps {
  setSelectedStudent: (student: Student) => void;
}

const StudentList: React.FC<StudentListProps> = ({ setSelectedStudent }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredStudents, setFilteredStudents] = useState(mockStudents);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);
    const filtered = mockStudents.filter(
      (student) =>
        student.name.toLowerCase().includes(term) ||
        student.course.toLowerCase().includes(term)
    );
    setFilteredStudents(filtered);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Student List</h2>
      <div className="mb-4 relative">
        <input
          type="text"
          placeholder="Search students..."
          className="w-full p-2 pl-10 border rounded-md"
          value={searchTerm}
          onChange={handleSearch}
        />
        <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Course</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredStudents.map((student) => (
              <tr
                key={student.id}
                className="hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedStudent(student)}
              >
                <td className="px-6 py-4 whitespace-nowrap">{student.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{student.course}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-16 bg-gray-200 rounded-full h-2.5">
                      <div
                        className={`h-2.5 rounded-full ${
                          student.performance >= 70 ? 'bg-green-600' : 'bg-red-600'
                        }`}
                        style={{ width: `${student.performance}%` }}
                      ></div>
                    </div>
                    <span className="ml-2">{student.performance}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {student.atRisk ? (
                    <span className="flex items-center text-red-600">
                      <AlertCircle size={16} className="mr-1" /> At Risk
                    </span>
                  ) : (
                    <span className="text-green-600">Good Standing</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentList;